case class Measurements(var processedFile:Int, var processedMeasurements:Int,var failedMeasurements:Int)
